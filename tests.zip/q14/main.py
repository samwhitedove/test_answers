owing = int(input("Value here: "))
isPaid = True
ok = True
if isPaid and owing > 100 <=200:
    ok = False
else:
    ok = True

print (ok)
