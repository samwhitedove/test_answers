def km(km)
    return km / 0.6

print(km(6))
