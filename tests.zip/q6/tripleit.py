def tripleit(number):
    returnValue = number * 3
    number = number + 1
    return returnValue

number = 3.3
if __name__ == '__main__':
    newNumber = tripleit(number)
